# Import modules
import arcpy

# Get a user defined variable to select the APRX of interest

example = arcpy.GetParameterAsText(0)

# This function takes in a source table and then checks for joins, lists the join name, properties, and the count of joins for the layer
def ListCIMJoins(c, join_count=0):
    if hasattr(c, 'sourceTable'):
        arcpy.AddMessage(f'       Join Name: {c.name}')
        arcpy.AddMessage(f'       Join Properties:')
        arcpy.AddMessage(f'         {c.destinationTable.workspaceConnectionString}')
        arcpy.AddMessage(f'         {c.destinationTable.dataset}')
        join_count += 1
        return ListCIMJoins(c.sourceTable, join_count)
    else:
        if join_count == 0:
            arcpy.AddMessage('       -> no join')

# join inventory (using CIM)

# Define an APRX to check for Joins
aprx = arcpy.mp.ArcGISProject(example)
m = aprx.listMaps()[0]

# For each layer in the map, get the amount of joins and arcpy.AddMessage out information as definied in the function above
for lyr in m.listLayers():
    arcpy.AddMessage(f"LAYER: {lyr.name}")
    if lyr.supports("dataSource"):
        lyrCIM = lyr.getDefinition("V2")
        if hasattr(lyrCIM, 'featureTable'):
            ListCIMJoins(lyrCIM.featureTable.dataConnection)