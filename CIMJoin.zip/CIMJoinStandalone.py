# Import modules
import arcpy

# This function takes in a source table and then checks for joins, lists the join name, properties, and the count of joins for the layer
def ListCIMJoins(c, join_count=0):
    if hasattr(c, 'sourceTable'):
        print(f'       Join Name: {c.name}')
        print(f'       Join Properties:')
        print(f'         {c.destinationTable.workspaceConnectionString}')
        print(f'         {c.destinationTable.dataset}')
        join_count += 1
        return ListCIMJoins(c.sourceTable, join_count)
    else:
        if join_count == 0:
            print('       -> no join')

# join inventory (using CIM)

# Define an APRX to check for Joins
aprx = arcpy.mp.ArcGISProject(r"C:\example.aprx")
m = aprx.listMaps()[0]

# For each layer in the map, get the amount of joins and print out information as definied in the function above
for lyr in m.listLayers():
    print(f"LAYER: {lyr.name}")
    if lyr.supports("dataSource"):
        lyrCIM = lyr.getDefinition("V2")
        if hasattr(lyrCIM, 'featureTable'):
            ListCIMJoins(lyrCIM.featureTable.dataConnection)